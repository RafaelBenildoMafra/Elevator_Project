package Main;
import java.util.LinkedList;
import java.util.List;

public class Elevador extends Thread{
	
	private Thread t;
	private String ThreadName = "Thread Main";
	private int inicio;
	private int fim;
	private int andarAtual = 1;
	private int cicloAtual = 0;
	private int destinoAtual = 1;
	private int NumeroCiclosPorAndar;
	private int sentido;
	List<Integer> andares = new LinkedList<>();
	List<Integer> fila = new LinkedList<>();
	
	public Elevador() {
		
	}
	
	public int getInicio() {
		return inicio;
	}

	public void setInicio(int inicio) {
		this.inicio = inicio;
	}


	public int getFim() {
		return fim;
	}


	public void setFim(int fim) {
		this.fim = fim;
	}

	
	public int getAndarAtual() {
		return andarAtual;
	}


	public void setAndarAtual(int andarAtual) {
		this.andarAtual = andarAtual;
	}


	public int getCicloAtual() {
		return cicloAtual;
	}


	public void setCicloAtual(int cicloAtual) {
		this.cicloAtual = cicloAtual;
	}


	public int getDestinoAtual() {
		return destinoAtual;
	}


	public void setDestinoAtual(int destinoAtual) {
		this.destinoAtual = destinoAtual;
	}


	public List<Integer> getFila() {
		return fila;
	}


	public void setFila(List<Integer> fila) {
		this.fila = fila;
	}


	public int getNumeroCiclosPorAndar() {
		return NumeroCiclosPorAndar;
	}

	public int getSentido() {
		return sentido;
	}

	public void setSentido(int sentido) {
		this.sentido = sentido;
	}

	public Elevador(int inicio, int fim) {
	
		this.inicio = inicio;
		this.fim = fim;	
		
		
		 for(int i = inicio+1; i <= fim; i++) {
			 
		    	andares.add(i);
		    }

	}
	

	public void setNumeroCiclosPorAndar(int numeroCiclosPorAndar) {
		
		NumeroCiclosPorAndar = numeroCiclosPorAndar;
		
	}
	

	public List<Integer> getAndares() {
		return andares;
	}


	public void setAndares(List<Integer> andares) {
		this.andares = andares;
	}


	public void addDestino(int destino) {
		
		fila.add(destino);
		
	}

	
	public void AtualizaStatus() {	
		
		if(destinoAtual == this.andarAtual && !fila.isEmpty()) { //verifica se chegou no destino intermediario
			
			destinoAtual = this.fila.get(0);  //Atualiza destinoAtual
			System.out.println("Movendo para: " + destinoAtual);
			this.fila.remove(0);
			
			if(this.cicloAtual < (NumeroCiclosPorAndar-1) && !fila.isEmpty()) {
					
				this.cicloAtual ++; //incrementa um ciclo
				
		}
	}
		
		else {

			if(this.cicloAtual >= (NumeroCiclosPorAndar-1)) { //verifica se finalizou os ciclos
				
				if(destinoAtual > this.andarAtual) { //sobe
					
					andarAtual++;
					
				}else if(destinoAtual < this.andarAtual) {
					 
					andarAtual--; //desce
					
				}
				
				this.cicloAtual = 0; //parado
			
			}else {
				
				this.cicloAtual ++; //se n�o finalizou incrementa um ciclo
				
			}
		}
	}
	
	@Override
	  public void start () {
	      //System.out.println("Starting " +  "Thread Main" );
	      if (t == null) {
	         t = new Thread (this, "Thread Main");
	         t.start ();
	      }
	   }
	
		@Override			
		public void run() {
			
			if(!fila.isEmpty()) {
				
				destinoAtual = fila.get(0);	//Insere a primeira posi��o da fila no destino
				System.out.println("Movendo para: " + destinoAtual);	
				fila.remove(0); //remove o destino da fila
					
			}
			
			while(true) {
					
					if(destinoAtual > andarAtual) { //SOBE
						
						sentido = 1;
						System.out.println("Andar=  " + andarAtual + " Sentido= 1-subindo ciclos= " + cicloAtual + " fila =" + fila.toString());
						AtualizaStatus();
						
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
						
					}else if(destinoAtual < andarAtual) { //DESCE
												
						sentido = 2;
						System.out.println("Andar=  " + andarAtual + " Sentido= 2-descendo ciclos= " + cicloAtual + " fila =" + fila.toString());
						AtualizaStatus();
						
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
					}else if(destinoAtual == andarAtual){ //PARADO
						
						sentido = 0;
						System.out.println("Andar=  " + andarAtual + " Sentido= 0-parado= " + cicloAtual + " fila =" + fila.toString());
										
						AtualizaStatus();
												
						
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
			
					 }				 										
			    }
		   }
}


	
	
	
	
	


