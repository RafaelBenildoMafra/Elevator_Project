package Main;
import GUI.*;

public class Principal {

	public static void main(String[] args) throws InterruptedException {
	
			
		Elevador elevador = new Elevador(0,10);
		PainelControle panel = new PainelControle(elevador);
		
		elevador.setNumeroCiclosPorAndar(2);
		
		elevador.start();
		panel.start();
		
		
		
	}

}

