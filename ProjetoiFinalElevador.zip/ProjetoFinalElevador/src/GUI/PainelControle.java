package GUI;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JFrame;

import Main.Elevador;

public class PainelControle extends Thread{
	
	
	JFrame frame = new JFrame();
	private Elevador elevador; //Cria vari�vel local Elevador que recebe o "valor" do elevador principal e pode ser utilizada nesta classe.
	private Thread t1;
	PainelBotoes botoes = new PainelBotoes();

	
	public PainelControle(Elevador elevador) {
		
		this.elevador = elevador;
		
		botoes.criaFormas((elevador.getAndares().size()));
		
		botoes.setAndares(elevador.getAndares().size()); //passa como parametro os andares do elevador para criar as formas.
			
		frame.setBounds(100, 100, 650, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setLayout(new BorderLayout());	
			
		frame.add(botoes);
		frame.setVisible(true);
		//frame.add(panel2);
		System.out.println(botoes.getFormas());
		
		HabilitaMouse(elevador);
			
	}
	
	
	
	public void HabilitaMouse(Elevador elevador) {
		
		botoes.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public synchronized void mouseClicked(MouseEvent e) {
				
				int x = e.getX();
				int y = e.getY();
				
				for (Formas forma: botoes.getFormas()) {
					
					if (forma.getShape().contains(x, y) == true) {
						
						if (!forma.isFilled() && forma.getTipo() == 1) {
							
							forma.setFilled(true);
							forma.setAtivo(true);
							elevador.addDestino(forma.getAndar());
							
						}else{
							
							//forma.setFilled(false);
							//forma.setAtivo(false);
						}
						
					}
				}
				
			}
		});
		
	}
	
	  @Override
	  public void start () {
	      //System.out.println("Starting " +  "Thread GUI" );
	      if (t1 == null) {
	         t1 = new Thread (this, "Thread GUI");
	         t1.start ();
	      }
	   }
	
		
	
		@Override	
		public void run() {		
			while(true) {
				
			List<Formas> formas = botoes.getFormas();
			
			//Controla os Botoes
			for(Formas forma: formas) {
				
				if(elevador.getDestinoAtual() == forma.getAndar() && forma.isAtivo() == true && forma.getTipo() == 1 && elevador.getAndarAtual() == forma.getAndar()) {
					
					forma.setAtivo(false);
					
				}
				
			}
			
			//Controla os Andares
			for(Formas forma: formas) {
				
				if(elevador.getAndarAtual() == forma.getAndar() && forma.getTipo() == 0) {
					
					forma.setAtivo(true);
					
				}else if(elevador.getAndarAtual() != forma.getAndar() && forma.getTipo() == 0){
					
					forma.setAtivo(false);
					
				}
				
			}
			
			//Controla Sentido
			for(Formas forma: formas) {
				
				forma.setSentido(elevador.getSentido());
				
			}

			botoes.repaint();

			
			try {
					Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			}
		}
	}
