package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JPanel;

import Main.Elevador;


public class PainelBotoes extends JPanel { 
	
	private int andares;

	public int getAndares() {
		return andares;
	}

	public void setAndares(int andares) {
		this.andares = andares;
	}


	private List<Formas> formas = new LinkedList<>();
	
	public List<Formas> getFormas() {
		return formas;
	}

	public void setFormas(List<Formas> formas) {
		this.formas = formas;
	}

	public void criaFormas(int andares) {
		
		for(int i = 0; i < andares; i++) {
			
		formas.add(new Formas(false ,50, 50 + i*70, 50, 50, 1, false,  andares-i, 0)); //Adiciona Botoes
		formas.add(new Formas(false ,500, 50 + i*70, 70, 70, 0, false, andares-i, 0));//Adiciona Andares
		
		}		
		
	}

	@Override
	public void paint(Graphics g) {
		
		paintComponents(g);
		paintElevador(g);
		
		

	}
	
	@Override
	public void paintComponents(Graphics g) {
		
		Graphics2D g2 = (Graphics2D)g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setColor(Color.black);
		
		int count = 0;
		
		//Shape triangulo = new Polygon(new int[] {107, 117, 127}, new int[] {81, 91, 81}, 3);
	    //Shape triangulo1 = new Polygon(new int[] {107, 117, 127}, new int[] {77, 67, 77}, 3);
	     
	    //g2.draw(triangulo);
	    //g2.draw(triangulo1);
		
		for (Formas forma: formas) {
			
			g2.draw(forma.getShape());
			g2.setFont(new Font("TimesNewRoman", Font.ROMAN_BASELINE, 14));
			
			if(forma.getTipo() == 1) {
				
				g2.drawString(""+forma.getAndar(), forma.getX() - 10, forma.getY() + 10);
				
				
			}else {
				
				g2.drawString(""+forma.getAndar(), forma.getX() + 80, forma.getY() + 10);
			}
				
			
			Shape retanguloPainel = new Rectangle2D.Float(35, forma.getY() - 10, 100, 70);
	          			        	    	  	    
	  	    Shape triangulo2 = new Polygon(new int[] {107, 117, 127}, new int[] {31 + forma.getY(), 41 + forma.getY(), 31 + forma.getY()}, 3);
	  	    Shape triangulo3 = new Polygon(new int[] {107, 117, 127}, new int[] {27 + forma.getY(), 17 + forma.getY(), 27 + forma.getY()}, 3);
	  	       	
	  	    g2.draw(triangulo2);
		    g2.draw(triangulo3);
		    g2.draw(retanguloPainel);
		    
		    
		    if(forma.getSentido() == 2) { //DESCENDO
		    	
		    	g2.fill(triangulo2);
				
		    	
		    }else if(forma.getSentido() == 1) { //SUBINDO
		    	
		    	g2.fill(triangulo3);
		    	
		    }else {
		    	
		    	g2.setColor(getBackground());
				g2.fill(triangulo2);
				g2.setColor(Color.black);
				g2.draw(triangulo2);
				
				g2.setColor(getBackground());
				g2.fill(triangulo3);
				g2.setColor(Color.black);
				g2.draw(triangulo3);
		    	
		    }
		      
	               
			
			if (forma.isFilled() && forma.isAtivo()) {
				
				g2.fill(forma.getShape());
				
			}
			
			if (!forma.isAtivo() && forma.isFilled()) {
				
				g2.setColor(getBackground());
				g2.fill(forma.getShape());
				g2.setColor(Color.black);
				g2.draw(forma.getShape());
				
				forma.setFilled(false);
				
			}	
				
		}
	}
	
	
	public void paintElevador(Graphics g) {
		
		Graphics2D g2 = (Graphics2D)g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setColor(Color.black);
		
		for (Formas forma: formas) {
			
			if (forma.getTipo() == 0 && forma.isAtivo()) {
						
				g2.fill(forma.getShape());
				forma.setFilled(true);
					
			}else if(forma.getTipo() == 0 && !forma.isAtivo()) {
				
				g2.setColor(getBackground());
				g2.fill(forma.getShape());
				g2.setColor(Color.black);
				g2.draw(forma.getShape());
				
				forma.setFilled(false);
				
			}
					
		}
		
	}
	


}
