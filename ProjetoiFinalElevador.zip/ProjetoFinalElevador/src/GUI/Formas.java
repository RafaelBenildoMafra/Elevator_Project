package GUI;

import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

public class Formas extends PainelBotoes{
	
	private boolean filled = false;
	private Shape forma;
	private int x; 
	private int y;
	private int larg;
	private int alt;
	private int tipo; //0 = retangulo, 1 = ellipse 
	private boolean ativo;
	private int andar;
	private int sentido;
	
	public Formas(boolean filled, int x,int y, int larg, int alt, int tipo, boolean ativo, int andar, int sentido) {
		
		this.filled = filled;
		this.x = x; 
		this.y = y; 
		this.larg = larg;
		this.alt = alt;
		this.ativo = ativo;
		this.andar = andar;
		this.sentido = sentido;
		
		
		if (tipo == 0) {
			
			this.forma = new Rectangle2D.Float(x,y, larg, alt);
			this.tipo = tipo;
			
		} else if(tipo == 1){
			
			this.forma = new Ellipse2D.Float(x,y, larg, alt);
			this.tipo = tipo;
			
		}else if(tipo == 2) {
			
			this.forma = new Polygon();
			
		}
		
		
	
	}

	public int getX() {
		return x;
	}


	public int getY() {
		return y;
	}


	public int getLarg() {
		return larg;
	}

	public void setLarg(int larg) {
		this.larg = larg;
		
	}

	public int getAlt() {
		return alt;
	}

	public void setAlt(int alt) {
		this.alt = alt;
		
	}

	public int getTipo() {
		return tipo;		
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
		
	}

	public boolean isFilled() {
		return filled;
	}

	public void setFilled(boolean filled) {
		this.filled = filled;
	}

	public Shape getShape() {
		return forma;
	}

	public void setShape(Shape shape) {
		this.forma = shape;
	}
	
	
	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}
	public int getAndar() {
		return andar;
	}

	public void setAndar(int andar) {
		this.andar = andar;
	}
	
	public int getSentido() {
		return sentido;
	}

	public void setSentido(int sentido) {
		this.sentido = sentido;
	}

	@Override
	public String toString() {
		return "Formas [filled=" + filled + ", forma=" + forma + ", x=" + x + ", y=" + y + ", larg=" + larg + ", alt="
				+ alt + ", tipo=" + tipo + ", ativo=" + ativo + ", andar=" + andar + "]";
	}

	
	

}
